package CECS277_Project;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class okAction implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        dispose();
    }

    private void dispose() {
    }
}
