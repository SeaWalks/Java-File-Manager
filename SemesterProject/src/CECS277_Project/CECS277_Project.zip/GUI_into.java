package CECS277_Project;

public class GUI_into {
    public static void main(String[] args){
        App app = new App();
        app.go();
    }
}
